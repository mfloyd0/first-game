import sys

print("Welcome to my game!")
passage = True
x = True
while passage == True:
  from jack import player 
   #name = input("Enter your name: ")
   #age = int(input("Enter your age: ")) 
  Player_1 = player()

  print("So your name is", Player_1.name, "and you are", Player_1.age)
  ans = input("correct?(yes/no) ").lower()
  if ans == "yes" and Player_1.age >= 18:
    print("Congrats, you're old enough to play!!")
    print("You're walking down a path and you see a house and a river.")   
    passage = False
  elif Player_1.age < 18:
    sys.exit("You're not old enough to play.")
  else:
    print("Please enter again!")
    continue
   


while ans != "house":
  ans = input("Do you enter the abonded house or try to cross the river? (house/river) ").lower()
  if ans == "river":
    print("a giant snake was in the river and ate you as you tried to swim across.")
    sys.exit("GAME OVER")
  elif ans == "house":
    print("You enter the house and you see a chest.")
    passage = True
  else:
    print("try again...")
    continue
  

while ans != "no":
  ans = input( "Do you open it? (yes/no) ").lower()
  if ans == "yes":
    print("there was a bomb in the chest and you died from the explosion.")
    sys.exit("GAME OVER")
  elif ans == "no":
    print("You make your back on your path.")
  else:
    print("try again..")
    continue

while ans != "fight":
  print("You encounter a ninja out of nowhere!!")
  ans = input("Do you fight or run?(fight/run) ").lower()
  if ans == "run":
    print("The ninja chase you like the coward you are and kills you")
    sys.exit("GAME OVER")

  elif ans == "fight":
    print("You fought hard against the ninja and managed to over power him.")
    passage = True
  else:
    print("try again")
    continue

while ans != "storm":
  print("You continue down the path and find ninja's hideout")
  ans = input("Do you Storm hideout or go home?(storm/home) ").lower()
  if ans == "home":
    print("You foolishly go home and the ninjas kill you in your sleep.")
    sys.exit("GAME OVER")
  elif ans == "storm":
    print("you storm the hidout and make it to the boss.")
    print("He looks very intimidating.")
    passage = False
  else:
    print("try again...")

while ans != "yes":
  ans = input("Are you sure you want to fight him?(yes/no) ").lower()
  if ans == "no":
    print("He kills you as you try to run away...")
    sys.exit("GAME OVER")
  elif ans == "yes":
    print("You fought you best and managed to defeat him...")
    print("Congrats you won the game!!")
    break 
  else:
    print("try again")
    continue 




