class player:
  def __init__(self):
    self.name = input("Enter your name: ")
    self.age = int(input("Enter your age: "))


class breaker:
  def __init__(self, name):
    self.name = name
  def endgame(self, name):
    print("GAME OVER")


